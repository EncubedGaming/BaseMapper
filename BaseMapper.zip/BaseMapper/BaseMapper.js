let fetch = require('node-fetch')
let fs = require('fs');
const readline = require('readline').createInterface({
  input: process.stdin,
  output: process.stdout
});
async function APICall(){
	let response = await fetch(`http://dynmap.weest.tv:8888/up/world/earth/1604872688971`);
	let mapDataString = await response.json();
	return mapDataString
}

let playerCords = ``
let playerX = ""
let playerY = ""
let playerZ = ""
let playerName = ""
let playerWorld = ""
let playerTotal = ``
let playerList = []
let runApi = 0

let fileName = ""
  	fs.readFile('./saves/save_info.txt', 'utf8', function (err,data) {
  if (err) {
    return console.log(err);
  }
  
   fileName = data
  // console.log(fileName)
});

async function main(){
//	if(runApi===0){
let mapDataString = await APICall()
//}




  	//playerList.push(mapDataString.hasStorm)
  	for (let p = 0; p < mapDataString.players.length; p++){
		playerWorld = mapDataString.players[p].world
		if (playerWorld!=="-some-other-bogus-world-"){
			playerName = mapDataString.players[p].name
			playerX = mapDataString.players[p].x
			playerY = mapDataString.players[p].y
			playerZ = mapDataString.players[p].z
			playerTotal = `${playerName} : ${playerX},${playerY},${playerZ} : ${playerWorld}`
			console.log(playerTotal)
			playerList.push(playerTotal)
		}
		if (playerWorld==="-some-other-bogus-world-"){
			playerName = mapDataString.players[p].name
			playerX = mapDataString.players[p].x
			playerY = mapDataString.players[p].y
			playerZ = mapDataString.players[p].z
			playerTotal = `${playerName} : World Unkown`
			console.log(playerTotal)
			playerList.push(playerTotal)
		}
	}

	commands(mapDataString,playerList)
	console.log(playerList)
}
readline.question('', command => {
	if (command.split("|")[0]==="load"){
		let fileOpenName = command.split("|")[1]
		fs.readFile(`./saves/${fileOpenName}.txt`, 'utf8', function (err,data) {
  if (err) {
    return console.log(err);
  }
  
   let mapDataString = data
   runApi = 1
	main(mapDataString)
  // console.log(fileName)
});

	} else if(command==="new"){main()}


})
function commands(mapDataString,playerList){
readline.question('', command => {
	//console.log(command.split("|")[0])
  if(command==="End"){
  	console.log("Ending...")
  	readline.close()
  } else if (command.split("|")[0]==="GetPlayerInfo") {
  	let playerArmor = mapDataString.players[command.split("|")[1]].armor
  	let playerHealth = mapDataString.players[command.split("|")[1]].health
  	console.log("Armor: "+playerArmor)
  	console.log("Health: "+playerHealth)



  }else if(command.split("|")[0]==="Save"){
  	let mapDataStringText = JSON.stringify(mapDataString)
  	//console.log(mapDataString)
  	fs.writeFile(`./saves/${fileName}.txt`, mapDataStringText, function (err) {
  if (err){console.log(err)};
  console.log('Saved');
  //console.log(mapDataString)
  fileName++
  console.log("Next file name:"+fileName)
  fs.writeFile(`./saves/save_info.txt`, fileName, function (err) {
  if (err){console.log(err)};
  //console.log('Saved');
  //fileName++
  //console.log("Next file name:"+fileName)
});
});
  }
  
  else {
  	console.log(`${command} is not a valid response`)
  	//commands()
 	readline.close()
 	
  }
  
});
}






