let fetch = require('node-fetch')
let fs = require('fs');
const readline = require('readline').createInterface({
  input: process.stdin,
  output: process.stdout
});
async function APICall(){
	console.log(dynmapURL)
	let response = await fetch(dynmapURL);
	let mapDataString = await response.json();
	return mapDataString
}

let playerCords = ``
let playerX = ""
let playerY = ""
let playerZ = ""
let playerName = ""
let playerWorld = ""
let playerTotal = ``
let playerList = []
let readInFile = ``
let dynmapURL = ``

let fileName = ""
  	fs.readFile('./saves/save_info.txt', 'utf8', function (err,data) {
  if (err) {
    return console.log(err);
  }
  
   fileName = data
  
});

async function main(){

	let mapDataString = await APICall()





  	//playerList.push(mapDataString.hasStorm)
  	for (let p = 0; p < mapDataString.players.length; p++){
		playerWorld = mapDataString.players[p].world
		if (playerWorld!=="-some-other-bogus-world-"){
			playerName = mapDataString.players[p].name
			playerX = mapDataString.players[p].x
			playerY = mapDataString.players[p].y
			playerZ = mapDataString.players[p].z
			playerTotal = `${playerName} : ${playerX},${playerY},${playerZ} : ${playerWorld}`
			console.log(playerTotal)
			playerList.push(playerTotal)
		}
		if (playerWorld==="-some-other-bogus-world-"){
			playerName = mapDataString.players[p].name
			playerX = mapDataString.players[p].x
			playerY = mapDataString.players[p].y
			playerZ = mapDataString.players[p].z
			playerTotal = `${playerName} : World Unkown`
			console.log(playerTotal)
			playerList.push(playerTotal)
		}
	}

	commands(mapDataString,playerList)
	console.log(playerList)
}
readline.question('', command => {
	if (command.split("|")[0]==="load"){
		let fileOpenName = command.split("|")[1]
		fs.readFile(`./saves/${fileOpenName}.txt`, 'utf8', function (err,data) {
  if (err) {
    return console.log(err);
  }
  
  readInFile = data
   
   
	main()
  
});

	} else if(command.split("|")[0]==="new"&&command.split("|")[1]!=="")

	{
		if (command.split("|")[1]!==""){
			
			dynmapURL = command.split("|")[1]
			console.log(dynmapURL)
			main()
		}



	}


})
function commands(mapDataString,playerList){
readline.question('', command => {

  if(command==="End"){
  	console.log("Ending...")
  	readline.close()
  } else if (command.split("|")[0]==="GetPlayerInfo") {
  	let playerArmor = mapDataString.players[command.split("|")[1]].armor
  	let playerHealth = mapDataString.players[command.split("|")[1]].health
  	console.log("Armor: "+playerArmor)
  	console.log("Health: "+playerHealth)



  }else if(command.split("|")[0]==="Save"){
  	let mapDataStringText = JSON.stringify(mapDataString)

  	fs.writeFile(`./saves/${fileName}.txt`, mapDataStringText, function (err) {
  if (err){console.log(err)};
  console.log('Saved');

  fileName++
  console.log("Next file name:"+fileName)
  fs.writeFile(`./saves/save_info.txt`, fileName, function (err) {
  if (err){console.log(err)};
  
});
});
  }
  
  else {
  	console.log(`${command} is not a valid response`)

 	readline.close()
 	
  }
  
});
}






